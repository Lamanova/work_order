class ApplicationController < ActionController::API
  include ExceptionHandler
end
