class WorkerSerializer < ActiveModel::Serializer
  attributes :id, :name, :company_name, :email
end
