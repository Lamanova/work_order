module Exceptions
  class LimitReachedError < StandardError; end
  class InvalidSortBy < StandardError; end
end
